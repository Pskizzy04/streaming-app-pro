# 🎬 Streaming App Pro

A full-featured secure streaming app with:

- 🔐 Firebase Authentication
- 💳 Stripe subscriptions
- 🧠 MongoDB user storage
- 📹 Protected video streaming (HLS)

## 🚀 Setup Instructions

1. Clone the repo  
2. Create `.env` file with:

```
PORT=3000
MONGODB_URI=your_mongo_connection
STRIPE_SECRET_KEY=your_stripe_key
FIREBASE_SERVICE_ACCOUNT='{"type":"service_account",...}'  # Full JSON object
```

3. Install dependencies:

```bash
npm install express firebase-admin dotenv stripe mongodb body-parser
```

4. Run the server:

```bash
node server.js
```

5. Open browser at `http://localhost:3000`

## 🔧 Required Setup

- [Firebase Console](https://console.firebase.google.com/)
  - Create project
  - Enable Google Sign-In
  - Get API key + Auth domain + App ID
  - Download service account JSON

- [MongoDB Atlas](https://www.mongodb.com/cloud/atlas)
  - Create DB & get connection string

- [Stripe](https://dashboard.stripe.com/)
  - Create account and get secret key

## 📄 License
MIT
