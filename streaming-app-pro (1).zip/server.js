const express = require('express');
const path = require('path');
const admin = require('firebase-admin');
const bodyParser = require('body-parser');
const { MongoClient } = require('mongodb');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Firebase Admin SDK
admin.initializeApp({
  credential: admin.credential.cert(JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT))
});

// MongoDB
let db;
MongoClient.connect(process.env.MONGODB_URI, {})
  .then(client => {
    db = client.db();
    console.log('✅ Connected to MongoDB');
  })
  .catch(err => console.error('❌ MongoDB connection error:', err));

app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

app.get('/get-stream', async (req, res) => {
  const idToken = req.headers.authorization?.split('Bearer ')[1];
  if (!idToken) return res.status(401).json({ success: false, message: 'No token' });

  try {
    const decoded = await admin.auth().verifyIdToken(idToken);
    const userEmail = decoded.email;

    // Check Stripe subscription status here (pseudo logic)
    // const customer = await stripe.customers.list({ email: userEmail });
    // const isSubscribed = true; // You'd check actual status

    // Skip real Stripe check for demo
    const isSubscribed = true;

    if (isSubscribed) {
      const streamUrl = 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8';
      res.json({ success: true, streamUrl });
    } else {
      res.status(403).json({ success: false, message: 'Subscription required' });
    }
  } catch (err) {
    res.status(401).json({ success: false, message: 'Invalid token' });
  }
});

app.listen(PORT, () => {
  console.log(`🚀 Streaming App Pro running at http://localhost:${PORT}`);
});
